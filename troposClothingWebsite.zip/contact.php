<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="style.css">
	<title>Contact Us</title>
</head>
<body>
<?php
    require 'navigation.php';
?>
<main id="main">
<figure>
    <figcaption><img src="troppos.png" alt="tropposlogo"></figcaption>
</figure>
<p>Our customer service team is available Monday to Friday 9am to 5pm (excluding UK national holidays).
	Get in touch with us via filling the form below.
	We will get back to you as quickly as possible, Monday to Friday within 24hrs to respond to your query.
</p>
<form action="submitpage.html">
	<fieldset>
		<legend><strong>Personal Information</strong></legend>
		<label for="fname">First name:</label>
		<input type="text" id="fname" name="fname" required><br>
		<label for="lname">Last name:</label>
		<input type="text" id="lname" name="lname"><br>
		<label for="email">Your email:</label>
		<input type="text" id="email"><br>
		<label for="number">Your phone number:</label>
		<input type="text" id="number"><br>
		<label for="ordnum">Order Number:</label>
		<input type="text" id="ordnum"><br>
		<label for="messagebox">Your message:</label>
		<textarea id="messagebox"></textarea><br><br>
		<button>Submit</button>
	</fieldset>	
</form>
</main>
<wbr>
<?php
    require 'footer.php';
?>
</body>
</html>