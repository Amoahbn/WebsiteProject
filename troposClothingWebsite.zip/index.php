<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tropos Clothing </title>
</head>
<body>
    <?php
    require 'db.php'; 
    require 'navigation.php';
?>
<main id="main">
<figure>
    <figcaption><img src="troppos.png" alt="tropposlogo"></figcaption>
</figure>
<h1>Products</h1>
<?php
$stmt = $pdo->query("SELECT products.*, categories.name AS category_name FROM products JOIN categories ON products.category_id = categories.id");
while ($row = $stmt->fetch()) {
    echo "<div>";
    echo "<h2>{$row['name']}</h2>";
    echo "<p>{$row['description']}</p>";
    echo "<p>Price: \${$row['price']}</p>";
    echo "<p>Category: {$row['category_name']}</p>";
    echo "<img src='images/{$row['image']}' width='100' height='100' alt= image>";
    echo "</div>";
}
?>
     <?php
    require 'footer.php';
    ?>
</body>
</html>







