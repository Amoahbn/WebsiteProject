<header>
     <h1>Tropos Clothing</h1>
    <a class="skip-navigation" href="#main">Skip to main content</a>
    <nav class="topnav">
	<a href="index.php">Home</a> 
	<a href="register.php" target="blank">Register New User</a>
	<a href="login.php" target="blank">Login</a>
	<a href="dashboard.php" target="blank">Admin Dashboard</a>
        <a href="aboutus.php" target="blank">About Us</a>
        <a href="recommendation.php" target="blank">Reviews</a>
        <a href="contact.php" target="blank">Contact Us</a>
    </nav>
</header>

