<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="style.css">
	<title>About Us</title>
</head>
<body>
<?php
    require 'navigation.php';
?>
<main id="main">
<figure>
    <figcaption><img src="troppos.png" alt="tropposlogo"></figcaption>
</figure>
<section>		
	<h2><cite>Tropos branding Co is the newest premium clothing brand!</cite></h2>
</section>
<blockquote><abbr title="Tropos Branding Co">TBC</abbr> was conceived with a single goal: to create
on-trend clothing with a high-end look and feel, but without the premium prices so everyone
can enjoy the style and quality of a designer brand.
In 2018, we started a key fashion trend with the creation of our signature Check Cropped Trousers. 
They were an instant hit, and we haven't stopped innovating since.Our half-belt,
slim-fit tapered trouser is another iconic style, designed to get you noticed fot all the right reasons.
</blockquote>
</main>
<hr>
<?php
    require 'footer.php';
?>
</body>
</html>