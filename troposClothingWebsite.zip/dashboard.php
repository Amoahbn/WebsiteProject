<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

echo "Welcome, " . $_SESSION['username'];
?>

<a href="dashboard.php?logout=1">Logout</a>


<h2>Manage Categories</h2>
<form method="POST" action="add_category.php">
    <input type="text" name="name" placeholder="Category Name" required>
    <button type="submit">Add Category</button>
</form>

<h2>Manage Products</h2>
<form method="POST" action="add_product.php" enctype="multipart/form-data">
    <input type="text" name="name" placeholder="Product Name" required>
    <textarea name="description" placeholder="Product Description"></textarea>
    <input type="number" name="price" step="0.01" placeholder="Price" required>
    <select name="category_id" required>
        <?php
        $stmt = $pdo->query("SELECT * FROM categories");
        while ($row = $stmt->fetch()) {
            echo "<option value='{$row['id']}'>{$row['name']}</option>";
        }
        ?>
    </select>
    <input type="file" name="image" required>
    <button type="submit">Add Product</button>
</form>


