<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="style.css">
    <title>Customer reviews</title>
</head>
<body>
<?php
    require 'navigation.php';
?>
<main id="main">
<figure>
    <figcaption><img src="troppos.png" alt="tropposlogo"></figcaption>
</figure>
<article>		
	<h2>Why review?</h2>
	<p>Leaving a review helps support the seller and shares 
		your unique experience with future buyers
	</p>
</article>	
<article>
	<h3>Customer reviews</h3>	
	<aside>
	<details open>
		<summary>4.3 ⭐⭐⭐⭐ average user rating based on 94 reviews.</summary>
		<p>5 star <meter value="0.9">90%</meter>82%</p>
		<p>4 star <meter value="0.7">70%</meter>56%</p>
		<p>3 star <meter value="0.1">10%</meter>5%</p>
		<p>2 star <meter value="0.5">50%</meter>70%</p>
		<p>1 star <meter value="0.5">50%</meter>70%</p>
	<hr>
		<h4>By feature</h4>
		<p>Comfort <meter value="0.9">90%</meter>90%</p>
		<p>Value for money <meter value="0.8">80%</meter>80%</p>
		<p>Communication <meter value="0.9">95%</meter>95%</p>	
	</details>
	</aside>
	</article>
<hr>	
<section>
	<details>
	<summary><mark>Top reviews</mark></summary>
	<fieldset>
		<legend><h5>👤&#8212; John Vernon</h5></legend>
		<p>⭐⭐⭐⭐⭐</p>
		<p><strong>Lovely fitting jacket</strong></p>
		<p>Reviewed in the <abbr title="United Kingdom">UK</abbr> on 21 October 2022<time> 14:34</time></p>
		<p>Size: M | Colour: Black/White</p>
		<p><q>Bought the jacket to match my joggers.Very good material.</q></p>
	</fieldset>
<wbr>	
	<fieldset>
		<legend><h5>👤&#8212; Andrew Robinson</h5></legend>
		<p>⭐⭐⭐⭐</p>
		<p><strong>Very nice sweatshirt. Perfect size as ordered</strong></p>
		<p>Reviewed in the <abbr title="United Kingdom">UK</abbr> on 15 October 2022<time> 10:15</time></p>
		<p>Size: XL | Colour: Blue</p>
		<p><q>I like everything.The only thing is the sweatshirt is a bit big.</q></p>
	</fieldset>	
<wbr>	
	<fieldset>
		<legend><h5>👤&#8212; Mary Owen</h5></legend>
		<p>⭐⭐</p>
		<p><strong>This t-shirt feels like a plastic bag over your torso!</strong></p>
		<p>Reviewed in the <abbr title="Scotland">GB-SCT</abbr> on 4 September 2022<time> 21:20</time></p>
		<p>Size: L | Colour: White </p>
		<p><q>As soon as it arrived I immediately made the report.
			The description of the product is not true .In the description is written 100% cotton while checking the tag says 95% polyester. 
		</q></p>
	</fieldset>		
<wbr>
	<fieldset>
		<legend><h5>👤&#8212; Gary Smith</h5></legend>
		<p>⭐</p>
		<p><strong>I oredered S and they sent me a size XXL</strong></p>
		<p>Reviewed in the <abbr title="United Kigdom">UK</abbr> on 1 September 2022<time> 15:20</time></p>
		<p>Size: S | Colour: Red </p>
		<p><q>I ordered a small size and they sent me an XXL. I bought it for my daughter for her birthday, now i need to wait another 2 days to give her the gift.
			I'm really annoyed, I hope they can fix this issue.
		</q></p>
	</fieldset>		
<wbr>
	<fieldset>
		<legend><h5>👤&#8212; Michael Owusu</h5></legend>
		<p>⭐⭐⭐⭐⭐</p>
		<p><strong>Excellent hoodie, a classic of the brand</strong></p>
		<p>Reviewed in the <abbr title="United Kingdom">UK</abbr> on 25 August 2022<time> 12:30</time></p>
		<p>Size: M | Colour: Grey </p>
		<p><q>The hoodie fit me perfectly,and the hoodie itself is nice</q></p>
	</fieldset>
</details>	
</section>
<wbr>
<section>
	<details>
		<summary><mark>Reviews with images</mark></summary>
	<fieldset>
		<legend><h5>👤&#8212; Leonardo Filippi</h5></legend>
		<p>⭐⭐⭐⭐⭐</p>
		<p><strong>Excellent tracksuit, a classic of the brand</strong></p>
		<p>Reviewed in the <abbr title="United Kingdom">UK</abbr> on 12 November 2022<time> 13:33</time></p>
		<p>Size: M | Colour: Black </p>
		<p><q>The tracksuit fit me perfectly,and the tracksuit itself is nice</q></p>
		<figure>
			<img class="image1"src="tracksuit.jpg" alt="tracksuit">
		</figure>
	</fieldset>
<wbr>
	<fieldset>
		<legend><h5>👤&#8212; Jason Maddison</h5></legend>
		<p>⭐⭐⭐⭐⭐</p>
		<p><strong>The quality of the material is outstanding</strong></p>
		<p>Reviewed in the <abbr title="United Kingdom">UK</abbr> on 2 November 2022<time> 12:15</time></p>
		<p>Size: XS | Colour: Grey </p>
		<p><q>The quality of the marerial, the fit and the style are perfect</q></p>
		<figure>
			<img class="image2" src="hoodie.jpg" alt="hodie">
		</figure>
	</fieldset>
	</details>
</section>
</main>
<wbr>
<?php
    require 'footer.php';
?>
</body>
</html>
