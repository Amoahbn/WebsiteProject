<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tropos Clothing </title>
</head>
<footer>Stay up to date with everything we're getting up to on socials.
    Tag us in your favourite Tropos fits with @troposbrandingco.
    While using this site, you agreed and accepted our terms of use, cookie and privacy policy. 
    All Rights Reserved.
    &copy;2022 This page was created by Benny Amoah.TROPOS BRANDING CO &reg;</footer>


