-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 12, 2024 at 11:31 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tropos_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'men'),
(3, 'women');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL,
  `category_id` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `category_id`, `image`) VALUES
(1, 'TROPOS TAUPE EMBOSSD SWEATSHIRT', 'men top', 23.00, 1, 'blob.jpg'),
(2, 'TROPOS WHITE PREMIUM LOGO COLLAR POLO', 'men top', 26.00, 1, 'blobb.jpg'),
(3, 'TROPOS BLACK TROUSERS WITH TONAL HALF BELT', 'men trousers', 22.00, 1, 'lb.jfif'),
(4, 'TROPOS WOMENS BLACK BODYSUIT', 'women dress', 30.00, 3, 'body.jfif'),
(5, 'TROPOS WOMENS OATMEAL BELTED BLAZER', 'women blazer', 25.00, 3, 'blazer.jfif'),
(6, 'TROPOS WOMENS AOIFE GREY EMBOSSED FAUX LEATHER JACKET', 'women jacket', 45.00, 3, 'tros.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'benny', '$2y$10$06nR17pq21Wocl01u6b7uum1w0LoWGpMYKyL5fmK2dSz4IVPqNLIy', 'admin'),
(2, 'james', '$2y$10$wl3tgQkzQOEpnZZZHuLOouyN/yXJ2Wg0RqF3ZyxBX/bMDdYegqlDG', 'admin'),
(3, 'chris', '$2y$10$m4utVpwzgcieyrFuO4ATZuWDg3fmvuOvQxuxeugI8vfBrzBrNrrim', 'admin'),
(4, 'esther', '$2y$10$L2xjQlzUDYYSvn5PEbkUmuPcDwiH//FPpLsWNMdzF0WL4hjD5aChu', 'admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
